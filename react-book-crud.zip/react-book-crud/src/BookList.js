
function BookList({ books, onEdit, onDelete }) {
  if (books.length === 0) return <p>Chưa có sách nào.</p>;

  return (
    <ul>
      {books.map((book) => (
        <li key={book.id}>
          <strong>{book.title}</strong> - {book.author}
          <button onClick={() => onEdit(book)}>Sửa</button>
          <button onClick={() => onDelete(book.id)}>Xoá</button>
        </li>
      ))}
    </ul>
  );
}

export default BookList;

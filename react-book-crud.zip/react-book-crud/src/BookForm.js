
import { useEffect, useState } from 'react';

function BookForm({ onAdd, onEdit, editingBook }) {
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');

  useEffect(() => {
    if (editingBook) {
      setTitle(editingBook.title);
      setAuthor(editingBook.author);
    }
  }, [editingBook]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title || !author) return;

    const newBook = { title, author };

    if (editingBook) {
      onEdit({ ...newBook, id: editingBook.id });
    } else {
      onAdd(newBook);
    }

    setTitle('');
    setAuthor('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        placeholder="Tên sách"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      <input
        placeholder="Tác giả"
        value={author}
        onChange={(e) => setAuthor(e.target.value)}
      />
      <button type="submit">{editingBook ? 'Cập nhật' : 'Thêm'}</button>
    </form>
  );
}

export default BookForm;

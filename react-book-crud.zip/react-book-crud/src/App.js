
import { useState, useEffect } from 'react';
import BookList from './BookList';
import BookForm from './BookForm';

function App() {
  const [books, setBooks] = useState(() => {
    const stored = localStorage.getItem('books');
    return stored ? JSON.parse(stored) : [];
  });

  const [editingBook, setEditingBook] = useState(null);

  useEffect(() => {
    localStorage.setItem('books', JSON.stringify(books));
  }, [books]);

  const handleAdd = (book) => {
    setBooks([...books, { ...book, id: Date.now() }]);
  };

  const handleEdit = (book) => {
    setBooks(books.map(b => b.id === book.id ? book : b));
    setEditingBook(null);
  };

  const handleDelete = (id) => {
    setBooks(books.filter(b => b.id !== id));
  };

  const handleStartEdit = (book) => {
    setEditingBook(book);
  };

  return (
    <div className="container">
      <h1>Quản lý sách</h1>
      <BookForm onAdd={handleAdd} onEdit={handleEdit} editingBook={editingBook} />
      <BookList books={books} onEdit={handleStartEdit} onDelete={handleDelete} />
    </div>
  );
}

export default App;
